# Teacher Pro v3 — Native Android

This is a real Android app project, not a WebView wrapper.

## Technology
- Kotlin
- Jetpack Compose
- Material 3
- SQLite local database
- Native Android PIN lock
- Native day/night theme

## Implemented functional areas
- Premium Home Dashboard
- Groups
- Student management
- Attendance statuses
- Grades & Exams
- Score entry
- Editable Parent Reports
- WhatsApp parent handoff
- Center Accounts
- 100 EGP class fee
- 20 EGP Center share / 80 EGP Teacher share
- Separate 10 / 15 / 20 EGP sheet fees
- Outstanding balance calculation
- App PIN
- Night Mode
- Phone and tablet responsive Compose UI
- Offline local storage

## Build
GitHub Actions workflow:
`Build Teacher Pro v3 Native APK`

Artifact:
`Teacher-Pro-v3-Native-APK`
