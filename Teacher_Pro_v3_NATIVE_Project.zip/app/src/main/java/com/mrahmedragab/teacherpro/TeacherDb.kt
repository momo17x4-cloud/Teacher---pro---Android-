package com.mrahmedragab.teacherpro

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class GroupRow(
    val id: Long,
    val name: String,
    val level: String,
    val schedule: String,
    val type: String
)

data class StudentRow(
    val id: Long,
    val groupId: Long,
    val name: String,
    val parentPhone: String,
    val notes: String
)

data class AssessmentRow(
    val id: Long,
    val groupId: Long,
    val title: String,
    val type: String,
    val maxMark: Double,
    val date: String
)

data class ReportRow(
    val id: Long,
    val studentId: Long,
    val studentName: String,
    val title: String,
    val body: String,
    val updatedAt: String
)

class TeacherDb(context: Context) : SQLiteOpenHelper(context, "teacher_pro_native.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE groups(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                level TEXT NOT NULL,
                schedule TEXT NOT NULL,
                type TEXT NOT NULL
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE students(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                parent_phone TEXT NOT NULL DEFAULT '',
                notes TEXT NOT NULL DEFAULT ''
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE assessments(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                type TEXT NOT NULL,
                max_mark REAL NOT NULL,
                date TEXT NOT NULL
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE scores(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                assessment_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                score REAL NOT NULL,
                note TEXT NOT NULL DEFAULT '',
                UNIQUE(assessment_id, student_id)
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE attendance(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                session_date TEXT NOT NULL,
                status TEXT NOT NULL,
                UNIQUE(student_id, session_date)
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE reports(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                body TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE payments(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL,
                period TEXT NOT NULL,
                class_paid INTEGER NOT NULL DEFAULT 0,
                sheet_fee REAL NOT NULL DEFAULT 0,
                sheet_paid INTEGER NOT NULL DEFAULT 0,
                UNIQUE(student_id, period)
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun groups(): List<GroupRow> {
        readableDatabase.rawQuery("SELECT id,name,level,schedule,type FROM groups ORDER BY id DESC", null).use { c ->
            val out = mutableListOf<GroupRow>()
            while (c.moveToNext()) {
                out += GroupRow(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4))
            }
            return out
        }
    }

    fun addGroup(name: String, level: String, schedule: String, type: String): Long =
        writableDatabase.insert("groups", null, ContentValues().apply {
            put("name", name); put("level", level); put("schedule", schedule); put("type", type)
        })

    fun students(groupId: Long): List<StudentRow> {
        readableDatabase.rawQuery(
            "SELECT id,group_id,name,parent_phone,notes FROM students WHERE group_id=? ORDER BY name",
            arrayOf(groupId.toString())
        ).use { c ->
            val out = mutableListOf<StudentRow>()
            while (c.moveToNext()) {
                out += StudentRow(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getString(4))
            }
            return out
        }
    }

    fun allStudents(): List<StudentRow> {
        readableDatabase.rawQuery("SELECT id,group_id,name,parent_phone,notes FROM students ORDER BY name", null).use { c ->
            val out = mutableListOf<StudentRow>()
            while (c.moveToNext()) out += StudentRow(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getString(4))
            return out
        }
    }

    fun addStudent(groupId: Long, name: String, phone: String, notes: String): Long =
        writableDatabase.insert("students", null, ContentValues().apply {
            put("group_id", groupId); put("name", name); put("parent_phone", phone); put("notes", notes)
        })

    fun assessments(groupId: Long): List<AssessmentRow> {
        readableDatabase.rawQuery(
            "SELECT id,group_id,title,type,max_mark,date FROM assessments WHERE group_id=? ORDER BY id DESC",
            arrayOf(groupId.toString())
        ).use { c ->
            val out = mutableListOf<AssessmentRow>()
            while (c.moveToNext()) {
                out += AssessmentRow(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getDouble(4), c.getString(5))
            }
            return out
        }
    }

    fun allAssessments(): List<AssessmentRow> {
        readableDatabase.rawQuery(
            "SELECT id,group_id,title,type,max_mark,date FROM assessments ORDER BY id DESC", null
        ).use { c ->
            val out = mutableListOf<AssessmentRow>()
            while (c.moveToNext()) out += AssessmentRow(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getDouble(4), c.getString(5))
            return out
        }
    }

    fun addAssessment(groupId: Long, title: String, type: String, maxMark: Double, date: String): Long =
        writableDatabase.insert("assessments", null, ContentValues().apply {
            put("group_id", groupId); put("title", title); put("type", type); put("max_mark", maxMark); put("date", date)
        })

    fun setScore(assessmentId: Long, studentId: Long, score: Double, note: String = "") {
        writableDatabase.insertWithOnConflict("scores", null, ContentValues().apply {
            put("assessment_id", assessmentId); put("student_id", studentId); put("score", score); put("note", note)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun score(assessmentId: Long, studentId: Long): Double? {
        readableDatabase.rawQuery(
            "SELECT score FROM scores WHERE assessment_id=? AND student_id=?",
            arrayOf(assessmentId.toString(), studentId.toString())
        ).use { c -> return if (c.moveToFirst()) c.getDouble(0) else null }
    }

    fun setAttendance(groupId: Long, studentId: Long, date: String, status: String) {
        writableDatabase.insertWithOnConflict("attendance", null, ContentValues().apply {
            put("group_id", groupId); put("student_id", studentId); put("session_date", date); put("status", status)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun attendance(studentId: Long, date: String): String {
        readableDatabase.rawQuery(
            "SELECT status FROM attendance WHERE student_id=? AND session_date=?",
            arrayOf(studentId.toString(), date)
        ).use { c -> return if (c.moveToFirst()) c.getString(0) else "Present" }
    }

    fun addReport(studentId: Long, title: String, body: String, updatedAt: String): Long =
        writableDatabase.insert("reports", null, ContentValues().apply {
            put("student_id", studentId); put("title", title); put("body", body); put("updated_at", updatedAt)
        })

    fun updateReport(id: Long, title: String, body: String, updatedAt: String) {
        writableDatabase.update("reports", ContentValues().apply {
            put("title", title); put("body", body); put("updated_at", updatedAt)
        }, "id=?", arrayOf(id.toString()))
    }

    fun reports(): List<ReportRow> {
        readableDatabase.rawQuery("""
            SELECT r.id,r.student_id,s.name,r.title,r.body,r.updated_at
            FROM reports r JOIN students s ON s.id=r.student_id
            ORDER BY r.id DESC
        """.trimIndent(), null).use { c ->
            val out = mutableListOf<ReportRow>()
            while (c.moveToNext()) out += ReportRow(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5))
            return out
        }
    }

    fun setPayment(studentId: Long, period: String, classPaid: Boolean, sheetFee: Double, sheetPaid: Boolean) {
        writableDatabase.insertWithOnConflict("payments", null, ContentValues().apply {
            put("student_id", studentId); put("period", period); put("class_paid", if (classPaid) 1 else 0)
            put("sheet_fee", sheetFee); put("sheet_paid", if (sheetPaid) 1 else 0)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    data class Payment(val classPaid: Boolean, val sheetFee: Double, val sheetPaid: Boolean)

    fun payment(studentId: Long, period: String): Payment {
        readableDatabase.rawQuery(
            "SELECT class_paid,sheet_fee,sheet_paid FROM payments WHERE student_id=? AND period=?",
            arrayOf(studentId.toString(), period)
        ).use { c ->
            return if (c.moveToFirst()) Payment(c.getInt(0) == 1, c.getDouble(1), c.getInt(2) == 1)
            else Payment(false, 0.0, false)
        }
    }

    fun counts(): Triple<Int, Int, Int> {
        fun count(table: String) = readableDatabase.rawQuery("SELECT COUNT(*) FROM $table", null).use { c ->
            c.moveToFirst(); c.getInt(0)
        }
        return Triple(count("groups"), count("students"), count("assessments"))
    }
}
