package com.mrahmedragab.teacherpro

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Blue = Color(0xFF175CFF)
private val DeepBlue = Color(0xFF0A347F)
private val Soft = Color(0xFFF3F7FD)
private val Ink = Color(0xFF10203A)

private fun sha256(s: String): String =
    MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TeacherProRoot(applicationContext) }
    }
}

@Composable
fun TeacherProRoot(context: Context) {
    val prefs = remember { context.getSharedPreferences("teacher_pro_settings", Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var unlocked by remember { mutableStateOf(prefs.getString("pin_hash", null) == null) }

    val light = lightColorScheme(
        primary = Blue, secondary = Color(0xFF705CF6), background = Soft,
        surface = Color.White, onSurface = Ink
    )
    val darkScheme = darkColorScheme(
        primary = Color(0xFF78A6FF), secondary = Color(0xFF9A8BFF),
        background = Color(0xFF06101E), surface = Color(0xFF0E1B2E)
    )

    MaterialTheme(colorScheme = if (dark) darkScheme else light) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (!unlocked) {
                PinGate(context, prefs) { unlocked = true }
            } else {
                TeacherProApp(
                    context = context,
                    dark = dark,
                    onDark = {
                        dark = it
                        prefs.edit().putBoolean("dark", it).apply()
                    },
                    onLock = { unlocked = false }
                )
            }
        }
    }
}

@Composable
private fun PinGate(
    context: Context,
    prefs: android.content.SharedPreferences,
    onUnlocked: () -> Unit
) {
    val currentHash = prefs.getString("pin_hash", null)
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF071C49), Blue))
        ),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.padding(24.dp).widthIn(max = 430.dp),
            shape = RoundedCornerShape(30.dp)
        ) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Icon(Icons.Default.School, null, tint = Blue, modifier = Modifier.size(54.dp))
                Text("Teacher Pro", fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text(
                    if (currentHash == null) "Create your private app PIN" else "Enter your PIN",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f)
                )
                OutlinedTextField(
                    value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(8) },
                    label = { Text("PIN") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                if (currentHash == null) {
                    OutlinedTextField(
                        value = confirm, onValueChange = { confirm = it.filter(Char::isDigit).take(8) },
                        label = { Text("Confirm PIN") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
                Button(
                    onClick = {
                        if (pin.length < 4) error = "PIN must be at least 4 digits."
                        else if (currentHash == null) {
                            if (pin != confirm) error = "PINs do not match."
                            else {
                                prefs.edit().putString("pin_hash", sha256(pin)).apply()
                                onUnlocked()
                            }
                        } else {
                            if (sha256(pin) == currentHash) onUnlocked() else error = "Wrong PIN."
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(16.dp)
                ) { Text(if (currentHash == null) "Create PIN" else "Unlock") }
            }
        }
    }
}

enum class MainSection { HOME, GROUPS, EXAMS, REPORTS, ACCOUNTS, MORE }

@Composable
private fun TeacherProApp(
    context: Context,
    dark: Boolean,
    onDark: (Boolean) -> Unit,
    onLock: () -> Unit
) {
    val db = remember { TeacherDb(context) }
    var section by remember { mutableStateOf(MainSection.HOME) }
    var groupDetail by remember { mutableStateOf<Long?>(null) }
    var refresh by remember { mutableIntStateOf(0) }

    Scaffold(
        bottomBar = {
            if (groupDetail == null) NavigationBar {
                listOf(
                    Triple(MainSection.HOME, Icons.Default.Home, "Home"),
                    Triple(MainSection.GROUPS, Icons.Default.Groups, "Groups"),
                    Triple(MainSection.EXAMS, Icons.Default.Assessment, "Exams"),
                    Triple(MainSection.REPORTS, Icons.Default.Description, "Reports"),
                    Triple(MainSection.MORE, Icons.Default.MoreHoriz, "More")
                ).forEach { (s, icon, label) ->
                    NavigationBarItem(
                        selected = section == s,
                        onClick = { section = s },
                        icon = { Icon(icon, null) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (groupDetail != null) {
                GroupDetail(
                    context = context,
                    db = db,
                    groupId = groupDetail!!,
                    refreshKey = refresh,
                    onRefresh = { refresh++ },
                    onBack = { groupDetail = null }
                )
            } else {
                when (section) {
                    MainSection.HOME -> HomeScreen(db, refresh)
                    MainSection.GROUPS -> GroupsScreen(db, refresh, { refresh++ }) { groupDetail = it }
                    MainSection.EXAMS -> ExamsScreen(db, refresh)
                    MainSection.REPORTS -> ReportsScreen(context, db, refresh) { refresh++ }
                    MainSection.ACCOUNTS -> AccountsScreen(db, refresh) { refresh++ }
                    MainSection.MORE -> MoreScreen(dark, onDark, onLock) { section = MainSection.ACCOUNTS }
                }
            }
        }
    }
}

@Composable
private fun PageHeader(title: String, subtitle: String, back: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(18.dp, 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (back != null) {
            IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, null) }
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
        }
        Surface(
            color = Blue.copy(alpha = .12f), shape = RoundedCornerShape(14.dp)
        ) {
            Icon(Icons.Default.School, null, tint = Blue, modifier = Modifier.padding(10.dp).size(26.dp))
        }
    }
}

@Composable
private fun HomeScreen(db: TeacherDb, refresh: Int) {
    val counts = remember(refresh) { db.counts() }
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Box(
                Modifier.padding(16.dp).fillMaxWidth().height(220.dp)
                    .background(
                        Brush.linearGradient(listOf(DeepBlue, Blue, Color(0xFF4A7FFF))),
                        RoundedCornerShape(30.dp)
                    )
            ) {
                Column(
                    Modifier.padding(24.dp).fillMaxHeight(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("TEACHER PRO", color = Color.White.copy(.7f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Good day, Mr. Ahmed", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                        Text("Your classroom command center", color = Color.White.copy(.75f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        HeroStat("Groups", counts.first.toString())
                        HeroStat("Students", counts.second.toString())
                        HeroStat("Assessments", counts.third.toString())
                    }
                }
            }
        }
        item { SectionTitle("Quick overview") }
        item {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickCard("Sessions", "Attendance & flow", Icons.Default.CheckCircle, Modifier.weight(1f))
                QuickCard("Follow-up", "Reports & alerts", Icons.Default.Notifications, Modifier.weight(1f))
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
        item {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickCard("Grades", "Exams & scores", Icons.Default.BarChart, Modifier.weight(1f))
                QuickCard("Accounts", "Fees & balances", Icons.Default.AccountBalanceWallet, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun RowScope.HeroStat(label: String, value: String) {
    Surface(
        modifier = Modifier.weight(1f),
        color = Color.White.copy(alpha = .14f),
        shape = RoundedCornerShape(17.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text(label, color = Color.White.copy(.7f), fontSize = 10.sp)
        }
    }
}

@Composable
private fun QuickCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Surface(color = Blue.copy(.12f), shape = RoundedCornerShape(14.dp)) {
                Icon(icon, null, tint = Blue, modifier = Modifier.padding(10.dp))
            }
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
        }
    }
}

@Composable private fun SectionTitle(text: String) {
    Text(text, Modifier.padding(18.dp, 20.dp, 18.dp, 10.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun GroupsScreen(db: TeacherDb, refresh: Int, onRefresh: () -> Unit, onOpen: (Long) -> Unit) {
    val groups = remember(refresh) { db.groups() }
    var add by remember { mutableStateOf(false) }
    Column {
        PageHeader("My Groups", "Open a group to manage everything")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.End) {
            Button(onClick = { add = true }, shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("New Group")
            }
        }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(groups) { g ->
                Card(
                    Modifier.fillMaxWidth().clickable { onOpen(g.id) },
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = Blue.copy(.12f), shape = RoundedCornerShape(16.dp)) {
                            Icon(Icons.Default.Class, null, tint = Blue, modifier = Modifier.padding(12.dp))
                        }
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text(g.name, fontWeight = FontWeight.Black, fontSize = 17.sp)
                            Text("${g.level} • ${g.schedule}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
                        }
                        AssistChip(onClick = {}, label = { Text(g.type) })
                    }
                }
            }
        }
    }
    if (add) AddGroupDialog(db, { add = false }, { onRefresh(); add = false })
}

@Composable
private fun AddGroupDialog(db: TeacherDb, onDismiss: () -> Unit, onSaved: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var level by remember { mutableStateOf("") }
    var schedule by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Center") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Group") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Group name") })
                OutlinedTextField(level, { level = it }, label = { Text("Level") })
                OutlinedTextField(schedule, { schedule = it }, label = { Text("Schedule") })
                Row {
                    FilterChip(selected = type == "Center", onClick = { type = "Center" }, label = { Text("Center") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(selected = type == "Online", onClick = { type = "Online" }, label = { Text("Online") })
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank()) {
                    db.addGroup(name, level.ifBlank { "General" }, schedule.ifBlank { "Not set" }, type)
                    onSaved()
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun GroupDetail(
    context: Context,
    db: TeacherDb,
    groupId: Long,
    refreshKey: Int,
    onRefresh: () -> Unit,
    onBack: () -> Unit
) {
    val group = remember(refreshKey) { db.groups().firstOrNull { it.id == groupId } }
    val students = remember(refreshKey) { db.students(groupId) }
    val assessments = remember(refreshKey) { db.assessments(groupId) }
    var tab by remember { mutableIntStateOf(0) }
    var addStudent by remember { mutableStateOf(false) }
    var addAssessment by remember { mutableStateOf(false) }

    Column {
        PageHeader(group?.name ?: "Group", "${students.size} students • ${group?.schedule.orEmpty()}", onBack)
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
            listOf("Students","Attendance","Grades","Reports","Accounts").forEachIndexed { i, label ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) })
            }
        }
        when (tab) {
            0 -> {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.End) {
                    Button(onClick = { addStudent = true }) { Icon(Icons.Default.PersonAdd, null); Spacer(Modifier.width(6.dp)); Text("Add Student") }
                }
                LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(students) { s -> StudentCard(s) }
                }
            }
            1 -> AttendanceTab(db, groupId, students, refreshKey, onRefresh)
            2 -> {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.End) {
                    Button(onClick = { addAssessment = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("New Assessment") }
                }
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(assessments) { a -> AssessmentCard(db, a, students, refreshKey, onRefresh) }
                }
            }
            3 -> GroupReportsTab(context, db, students, refreshKey, onRefresh)
            4 -> GroupAccountsTab(db, students, refreshKey, onRefresh)
        }
    }

    if (addStudent) {
        var name by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var notes by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { addStudent = false },
            title = { Text("Add Student") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Student name") })
                    OutlinedTextField(phone, { phone = it }, label = { Text("Parent phone") })
                    OutlinedTextField(notes, { notes = it }, label = { Text("Private notes") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) {
                        db.addStudent(groupId, name, phone, notes); onRefresh(); addStudent = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { addStudent = false }) { Text("Cancel") } }
        )
    }

    if (addAssessment) {
        var title by remember { mutableStateOf("") }
        var type by remember { mutableStateOf("Quiz") }
        var max by remember { mutableStateOf("10") }
        val date = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
        AlertDialog(
            onDismissRequest = { addAssessment = false },
            title = { Text("New Assessment") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("Title") })
                    OutlinedTextField(type, { type = it }, label = { Text("Type: Quiz / Dictation / Exam") })
                    OutlinedTextField(max, { max = it }, label = { Text("Full mark") })
                    Text("Date: $date")
                }
            },
            confirmButton = {
                Button(onClick = {
                    db.addAssessment(groupId, title.ifBlank { type }, type, max.toDoubleOrNull() ?: 10.0, date)
                    onRefresh(); addAssessment = false
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { addAssessment = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun StudentCard(s: StudentRow) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(14.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Blue.copy(.12f), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Person, null, tint = Blue, modifier = Modifier.padding(10.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(s.name, fontWeight = FontWeight.Bold)
                Text(s.parentPhone.ifBlank { "No parent phone" }, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
            }
            if (s.notes.isNotBlank()) Icon(Icons.Default.StickyNote2, null, tint = Color(0xFFF5A623))
        }
    }
}

@Composable
private fun AttendanceTab(db: TeacherDb, groupId: Long, students: List<StudentRow>, refresh: Int, onRefresh: () -> Unit) {
    val date = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    Column {
        Text("Today's attendance • $date", Modifier.padding(16.dp), fontWeight = FontWeight.Bold)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(students) { s ->
                var status by remember(refresh, s.id) { mutableStateOf(db.attendance(s.id, date)) }
                Card(shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text(s.name, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Present","Late","Excused","No Excuse").forEach { value ->
                                FilterChip(
                                    selected = status == value,
                                    onClick = {
                                        status = value
                                        db.setAttendance(groupId, s.id, date, value)
                                        onRefresh()
                                    },
                                    label = { Text(value, fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AssessmentCard(db: TeacherDb, a: AssessmentRow, students: List<StudentRow>, refresh: Int, onRefresh: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().clickable { open = !open }, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(a.title, fontWeight = FontWeight.Black)
                    Text("${a.type} • ${a.date} • /${a.maxMark.toInt()}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
                }
                Icon(if (open) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
            }
            if (open) {
                HorizontalDivider()
                students.forEach { s ->
                    var mark by remember(refresh, a.id, s.id) { mutableStateOf(db.score(a.id, s.id)?.toString().orEmpty()) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(s.name, Modifier.weight(1f), fontSize = 13.sp)
                        OutlinedTextField(
                            value = mark,
                            onValueChange = {
                                mark = it
                                it.toDoubleOrNull()?.let { v -> db.setScore(a.id, s.id, v.coerceAtMost(a.maxMark)); onRefresh() }
                            },
                            modifier = Modifier.width(92.dp),
                            singleLine = true,
                            label = { Text("Score") }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupReportsTab(context: Context, db: TeacherDb, students: List<StudentRow>, refresh: Int, onRefresh: () -> Unit) {
    var selected by remember { mutableStateOf<StudentRow?>(null) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(students) { s ->
            Card(Modifier.fillMaxWidth().clickable { selected = s }, shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Description, null, tint = Blue)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.name, fontWeight = FontWeight.Bold)
                        Text("Create or edit parent report", fontSize = 11.sp)
                    }
                    Icon(Icons.Default.ChevronRight, null)
                }
            }
        }
    }
    selected?.let { s ->
        var title by remember { mutableStateOf("Student Follow-up") }
        var body by remember {
            mutableStateOf(
                "Dear Parent,\n\n${s.name}'s latest classroom follow-up is ready.\nPlease review attendance, grades, homework and required tasks.\n\nMr. Ahmed Ragab"
            )
        }
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text("Parent Report • ${s.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("Title") })
                    OutlinedTextField(body, { body = it }, label = { Text("Editable report") }, minLines = 7)
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = {
                        val phone = s.parentPhone.filter(Char::isDigit)
                        if (phone.isNotBlank()) {
                            val uri = Uri.parse("https://wa.me/$phone?text=${Uri.encode(body)}")
                            context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    }) { Text("WhatsApp") }
                    Button(onClick = {
                        db.addReport(s.id, title, body, SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()))
                        onRefresh(); selected = null
                    }) { Text("Save") }
                }
            },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun GroupAccountsTab(db: TeacherDb, students: List<StudentRow>, refresh: Int, onRefresh: () -> Unit) {
    val period = remember { SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date()) }
    Column {
        Card(Modifier.padding(16.dp).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Blue)) {
            Column(Modifier.padding(18.dp)) {
                Text("Center Rules", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                Text("Class fee 100 EGP • Center 20 EGP • Teacher 80 EGP", color = Color.White.copy(.8f))
                Text("Sheet fees: 10 / 15 / 20 EGP • tracked separately", color = Color.White.copy(.8f))
            }
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(students) { s ->
                val pay = remember(refresh, s.id) { db.payment(s.id, period) }
                var classPaid by remember(refresh, s.id) { mutableStateOf(pay.classPaid) }
                var sheetFee by remember(refresh, s.id) { mutableStateOf(pay.sheetFee) }
                var sheetPaid by remember(refresh, s.id) { mutableStateOf(pay.sheetPaid) }
                Card(shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text(s.name, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(classPaid, {
                                classPaid = it; db.setPayment(s.id, period, classPaid, sheetFee, sheetPaid); onRefresh()
                            })
                            Text("Class 100 EGP paid")
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(0.0,10.0,15.0,20.0).forEach { fee ->
                                FilterChip(selected = sheetFee == fee, onClick = {
                                    sheetFee = fee; db.setPayment(s.id, period, classPaid, sheetFee, sheetPaid); onRefresh()
                                }, label = { Text(if (fee == 0.0) "No sheet" else "${fee.toInt()} EGP") })
                            }
                        }
                        if (sheetFee > 0) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(sheetPaid, {
                                    sheetPaid = it; db.setPayment(s.id, period, classPaid, sheetFee, sheetPaid); onRefresh()
                                })
                                Text("Sheet paid")
                            }
                        }
                        val due = (if (classPaid) 0.0 else 100.0) + (if (sheetFee > 0 && !sheetPaid) sheetFee else 0.0)
                        Text("Outstanding: ${due.toInt()} EGP", color = if (due > 0) Color(0xFFEF476F) else Color(0xFF18B66A), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ExamsScreen(db: TeacherDb, refresh: Int) {
    val assessments = remember(refresh) { db.allAssessments() }
    Column {
        PageHeader("Grades & Exams", "All assessments across your groups")
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(assessments) { a ->
                Card(shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(15.dp).fillMaxWidth()) {
                        Icon(Icons.Default.Assessment, null, tint = Blue)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(a.title, fontWeight = FontWeight.Bold)
                            Text("${a.type} • ${a.date} • Full mark ${a.maxMark.toInt()}", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportsScreen(context: Context, db: TeacherDb, refresh: Int, onRefresh: () -> Unit) {
    val reports = remember(refresh) { db.reports() }
    var editing by remember { mutableStateOf<ReportRow?>(null) }
    Column {
        PageHeader("Saved Reports", "Edit saved reports at any time")
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(reports) { r ->
                Card(Modifier.fillMaxWidth().clickable { editing = r }, shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(15.dp)) {
                        Text(r.studentName, fontWeight = FontWeight.Black)
                        Text(r.title, fontWeight = FontWeight.Bold)
                        Text(r.body.take(90) + if (r.body.length > 90) "…" else "", fontSize = 11.sp)
                        Text("Updated ${r.updatedAt}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.45f))
                    }
                }
            }
        }
    }
    editing?.let { r ->
        var title by remember { mutableStateOf(r.title) }
        var body by remember { mutableStateOf(r.body) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Edit Report") },
            text = {
                Column {
                    OutlinedTextField(title, { title = it }, label = { Text("Title") })
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(body, { body = it }, label = { Text("Report") }, minLines = 8)
                }
            },
            confirmButton = {
                Button(onClick = {
                    db.updateReport(r.id, title, body, SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()))
                    onRefresh(); editing = null
                }) { Text("Save Changes") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun AccountsScreen(db: TeacherDb, refresh: Int, onRefresh: () -> Unit) {
    val students = remember(refresh) { db.allStudents() }
    Column {
        PageHeader("Accounts", "Center & student payment overview")
        GroupAccountsTab(db, students, refresh, onRefresh)
    }
}

@Composable
private fun MoreScreen(dark: Boolean, onDark: (Boolean) -> Unit, onLock: () -> Unit, onAccounts: () -> Unit) {
    Column {
        PageHeader("More", "Teacher Pro settings")
        Card(Modifier.padding(16.dp).fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
            Column {
                ListItem(
                    headlineContent = { Text("Night Mode") },
                    supportingContent = { Text("True native dark theme") },
                    leadingContent = { Icon(Icons.Default.DarkMode, null) },
                    trailingContent = { Switch(dark, onDark) }
                )
                HorizontalDivider()
                ListItem(
                    headlineContent = { Text("Accounts") },
                    supportingContent = { Text("Payments, sheet fees and balances") },
                    leadingContent = { Icon(Icons.Default.AccountBalanceWallet, null) },
                    modifier = Modifier.clickable(onClick = onAccounts)
                )
                HorizontalDivider()
                ListItem(
                    headlineContent = { Text("Lock App") },
                    supportingContent = { Text("Require your PIN again") },
                    leadingContent = { Icon(Icons.Default.Lock, null) },
                    modifier = Modifier.clickable(onClick = onLock)
                )
            }
        }
        Text(
            "Teacher Pro v3.0 Native\nKotlin + Jetpack Compose • Offline SQLite database",
            Modifier.padding(20.dp),
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(.55f)
        )
    }
}
