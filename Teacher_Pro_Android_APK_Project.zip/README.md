# Teacher Pro Android APK Project

This Android project wraps the Teacher Pro v2.5 Premium UI as a native Android WebView app.

## App identity
- App: Teacher Pro
- Package: com.mrahmedragab.teacherpro
- Version: 2.5.0
- Minimum Android: 7.0 (API 24)
- Target Android: API 35

## Included
- Full Teacher Pro Premium UI inside the APK.
- LocalStorage persistence for students, groups, sessions, grades, reports, accounts, password and Night Mode.
- Works offline because the UI is bundled under `android_asset`.
- External WhatsApp/phone/web links open with Android apps.
- JSON backup export uses Android Downloads.
- JSON import uses Android's file picker.
- GitHub Actions workflow builds an installable debug APK.

## Important
This APK build is local-first. It does not add live cloud sync between two devices. Live sync needs a hosted backend/database.
